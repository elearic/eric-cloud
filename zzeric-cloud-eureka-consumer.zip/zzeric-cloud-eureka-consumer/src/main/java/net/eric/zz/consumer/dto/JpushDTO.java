package net.eric.zz.consumer.dto;

import lombok.Data;

/**
 *
 *  
 *  * @author zz_huns  
 *  @version Id: JpushDTO.java, v 0.1 2020/6/18 2:38 PM zz_huns Exp $$
 *
 */
@Data
public class JpushDTO {

    private String regId;

    private String alias;

}
